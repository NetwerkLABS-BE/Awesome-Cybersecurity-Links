# Resource Suggestion Template

**Title:**

**Link:**

**Category (Blue/Red/Purple/CTF/Blog/Tool):**

**Short Description:**

**Why it should be included:**

Thank you for your suggestion! 🙌
